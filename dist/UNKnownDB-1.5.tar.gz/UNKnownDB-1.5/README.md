# CleverSQL
A new SQL
